const products = [
    {
      name: "Choclate Milk",
      imageUrl:
        "https://images.unsplash.com/photo-1586533350279-cfa516d2d832?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      description:
        "Chocolate milk is chocolate-flavored milk made by mixing cocoa solid with milk. It is a food pairing where the mouthfeel of the milk masks the dietary fibers in the cocoa solid",
      price: 500,
      countInStock: 15,
    },
    {
      name: "1Kg Rice Packet",
      imageUrl:
        "https://images.unsplash.com/photo-1613758235256-43a7bdc21d82?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      description:
        "Rice is the seed of the grass species Oryza sativa or less commonly Oryza glaberrima. The name wild rice is usually used for species of the genera Zizania and Porteresia, both wild and domesticated, although the term may also be used for primitive or uncultivated varieties of Oryza",
      price: 220,
      countInStock: 10,
    },
    {
      name: "Bicuits",
      imageUrl:
        "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=765&q=80",
      description:
        "A flour-based baked and shaped food product. In most countries biscuits are typically hard, flat, and unleavened. They are usually sweet and may be made with sugar, chocolate, icing, jam, ginger, or cinnamon.",
      price: 250,
      countInStock: 5,
    },
    {
      name: "Bread",
      imageUrl:
        "https://images.unsplash.com/photo-1598373182133-52452f7691ef?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      description:
        "Bread is a staple food prepared from a dough of flour and water, usually by baking. Throughout recorded history and around the world, it has been an important part of many cultures' diet. ",
      price: 75,
      countInStock: 25,
    },
    {
      name: "Sugar",
      imageUrl:
        "https://images.unsplash.com/photo-1610219171189-286769cc9b20?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      description:
        "Sugar is the generic name for sweet-tasting, soluble carbohydrates, many of which are used in food. Simple sugars, also called monosaccharides, include glucose, fructose, and galactose.",
      price: 215,
      countInStock: 4,
    },
    {
      name: "Eggs",
      imageUrl:
        "https://images.unsplash.com/photo-1518569656558-1f25e69d93d7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      description:
        "Eggs are a nutritious protein source and a staple in many people's diets. Though they're high in cholesterol, they also have many health-promoting qualities. For healthy adults, eating 1–2 eggs a day appears safe, as long as they're consumed as part of an overall nutritious diet.",
      price: 405,
      countInStock: 10,
    },
  ];
  
  module.exports = products;
  