// import React from "react";
// import { Card, Col, Row } from "react-bootstrap";
// //import { Button } from "react-bootstrap";


// // import employee from "../images/welcome.jpg";
// // import department from "../images/department.webp" 
// //import { Container } from "react-bootstrap";
// // import product from '../Img/product.png'
// // import vehicle from '../Img/vehicle.png'
// // import customer from '../Img/cus.png'
// // import stock from '../Img/stock.png'
// // import order from '../Img/order.png'
// // import appoinment from '../Img/appointment.png'
// import { Link } from "react-router-dom"

// const AdminDashBoard = () => {
//   return (
//     <div>
//     <div className="container">
//     <div className="row">
//               <div className="col-md-8 mx-auto">

//                   <div className="card">
//                       <div className="card-body">
//                           <div className="row">
//                               <div className="col">
//                                   <center>
//                                       <h3 >HOME</h3>
//                                   </center>
//                               </div>
//                           </div>

//                           <div className="row">
//                               <div className="col">
//                                   <hr />
//                               </div>
//                           </div>
//       <Row md={1}  className="g-4" >
//           <Col>
//             <Link to = "/add">
//             <Card bg="success" text="light" style={{ width: "10rem", height :"12rem"}}>
//             {/* <Card.images variant="top" src={employee}></Card.images> */}
//             <Card.Body>
//               <Card.Title>Profile Management</Card.Title>
//             </Card.Body>
//           </Card>
//           </Link>
//         </Col>
//            <Col>
//             <Link to = "/addD">
//           <Card bg="success" text="light" style={{ width: "10rem", height :"12rem" }}>
//             {/* <Card.Img variant="top" src={department} /> */}
//             <Card.Body>
//               <Card.Title>Department Management </Card.Title>
//             </Card.Body>
//           </Card>
//           </Link>
//         </Col> 
        
        
        
//         <Col >
//          <Link to = "/addS">
//           <Card bg="success" text="light" style={{ width: "10rem" , height :"12rem"}}>
//               {/* <Card.Img variant="top" src={stock}  /> */}
//             <Card.Body>
//               <Card.Title>Salary Management</Card.Title>
//             </Card.Body>
//           </Card>
//           </Link>
//         </Col>  
//           {/* <Col >
//          <Link to = "/Stock.js">
//           <Card bg="success" text="light" style={{ width: "18rem" , height :"25rem"}}>
//               <Card.Img variant="top" src={stock}  />
//             <Card.Body>
//               <Card.Title>Stock Management</Card.Title>
//             </Card.Body>
//           </Card>
//           </Link>
//           </Col> */}
          
        
//       </Row>
//       </div> 
//       </div>
//        </div>
//        </div>
//        </div>
//        </div>
    
//   );
// };

// export default AdminDashBoard;

    